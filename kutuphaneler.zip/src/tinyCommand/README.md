# tinyCommand
sentence=A simple Arduino IDE library for serial command processing.
# 0.1.0
